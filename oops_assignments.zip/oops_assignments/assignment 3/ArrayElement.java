class ArrayElement
{
 public static void main(String args[])
  {
    int arr[] = { 2,6,8,12,14,16 };
    
    for(int i=0;i<6;i++)
    {
      System.out.print(arr[i]+"  ");
     }
   }
}