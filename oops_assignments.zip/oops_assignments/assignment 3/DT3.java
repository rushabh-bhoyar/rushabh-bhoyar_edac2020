class DT3
{
public static void main(String args[])
 {
  float f = 40.567F;
  int a = (int)f;
  
  System.out.println(a);
  System.out.println(f); 
    
  }
}