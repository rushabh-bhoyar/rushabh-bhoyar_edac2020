/* Declaration of array*/


// Declaration of Integer array

int arr[];
arr = new int[5];
int arr = new int[5];

int arr[] = { 5,10,15,20,25,30 };

// Declartion of Float array

float arr1[];
arr1 = new float[4];
float arr1 = new float
float arr1[] = { 2.5,4.0,6.5,7.0 };

// Declaration of Double array

double arr2 [];
arr2 = new double [5];
double arr2 = new arr2 [5];
double arr2[] = { 10.00, 23.34, 45.56, 20.20, 12.50}
