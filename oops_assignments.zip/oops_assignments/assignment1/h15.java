import java.util.Scanner;
class h15
{
public static void main(String args[])
{
char p;
System.out.println("Enter m or f  ");
Scanner sc= new Scanner(System.in);
p=sc.next().charAt(0);
System.out.println("enter the age of person :");
int age=sc.nextInt();
switch(p)
{
case 'm':
if(age>=18)
System.out.println("eligible for marriage");
break;
case 'f':
if(age>=18)
System.out.println("eligible for marriage");
break;
default:
System.out.println("Not eligible for marriage");

}
}
}