import java.util.Scanner;
class h9
{
public static void main(String args[])
{
int a,year,month,day;
Scanner sc= new Scanner(System.in);
System.out.println("no of days:  ");
a=sc.nextInt();
year = a/365;
a=a%365;
System.out.println("years =  " +year);
month=a/30;
a=a%30;
System.out.println("months =  " +month);
day=a;
System.out.println("days =  " +day);
}
}
