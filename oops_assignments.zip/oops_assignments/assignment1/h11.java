import java.util.Scanner;
class h11
{
public static void main(String args[ ])
{
int x=10;
int y=20;

System.out.println("befor swaping");
System.out.println("x =  " + x);
System.out.println("y =  " +y);

System.out.println("after swapping");
x=x+y;
y=x-y;
x=x-y;
System.out.println("x =  " + x);
System.out.println("y =  " +y);
}
}
