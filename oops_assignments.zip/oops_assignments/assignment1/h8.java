import java.util.Scanner;
class h8
{
public static void main(String args[])
{
Double p=10000.00;
double r=0.12;
double t;
Scanner sc= new Scanner(System.in);
System.out.println("time duretion  ");
t=sc.nextInt();
double si=p*(1+r*t);
System.out.println("simple interst=  " +si);
}
}
