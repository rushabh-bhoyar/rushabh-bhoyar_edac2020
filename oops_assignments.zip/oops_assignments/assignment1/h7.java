import java.util.Scanner;
class h7
{
public static void main(String args[])
{
int a,b,c,d,e;
Scanner sc= new Scanner(System.in);
System.out.println("subject1 marks");
a=sc.nextInt();
System.out.println("subject1 marks");
b=sc.nextInt();
System.out.println("subject1 marks");
c=sc.nextInt();
System.out.println("subject1 marks");
d=sc.nextInt();
System.out.println("subject1 marks");
e=sc.nextInt();
int f=a+b+c+d+e;
double i=(f*100)/500;
System.out.println("total marks= "+f);
System.out.println("percentage= "+i+"  %");
}
}
