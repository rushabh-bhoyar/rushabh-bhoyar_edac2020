import java.util.Scanner;
class h13
{
public static void main(String args[])
{
int year;
System.out.println("Enter a three nos ");
Scanner sc= new Scanner(System.in);
int x = sc.nextInt();
int y = sc.nextInt();
int z = sc.nextInt();
if(x>y && x>z)
{
System.out.println(x +"is greater");
}
else if(y>x && y>z)
{
System.out.println(y+"is greater");
}
else
{
String res=(z>x && z>y) ? "is greater" : "wrong no";
System.out.println(z+res);
}
}
}