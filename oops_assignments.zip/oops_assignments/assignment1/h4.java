
class h4
{
public static void main(String args[ ])
{
byte a=4;
byte b= 6;
byte c= (byte)(a+b);
System.out.println(c);
}
}
