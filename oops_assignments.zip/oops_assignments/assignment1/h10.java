import java.util.Scanner;
class h10
{
public static void main(String args[])
{
double f;
double c;
Scanner sc= new Scanner(System.in);
System.out.println("temperature in fahreneit  ");
f=sc.nextInt();
c=5*(f-32)/9;
System.out.println("temperature in celsius=  " +c);
}
}
