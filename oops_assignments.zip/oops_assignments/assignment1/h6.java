import java.util.Scanner;
class h6
{
public static void main(String args[])
{
double r,a,c;
double pi=3.14;
Scanner sc= new Scanner(System.in);
System.out.println("Enter the redius of circle");
r=sc.nextDouble();
a=pi*r*r;
c=2*pi*r;
System.out.println("area of circle = " + a);
System.out.println("circumference of circle = " + c);


}
}
