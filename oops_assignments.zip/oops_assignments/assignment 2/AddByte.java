class AddByte
{ 

 public static void main(String args[])
 {

  byte a= 1;
  byte b= 7;
  byte c=(byte)(a+b);
  
  System.out.println(c);

  }
}