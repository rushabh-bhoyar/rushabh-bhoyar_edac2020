package in.edac;

public class UserDao {
	
	 public void sayHi() {
		 
		 System.out.println("Hii Spring Boot...!!!");
		
	}

}
