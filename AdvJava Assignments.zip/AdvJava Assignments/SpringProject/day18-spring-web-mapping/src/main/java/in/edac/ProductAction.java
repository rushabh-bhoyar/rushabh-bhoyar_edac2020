package in.edac;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/product")
public class ProductAction {
	
	@GetMapping("/")
	public String productDemo() {
		return "New Products are ready to deliver.";
		
	}
	
	@GetMapping("/1")
	public String productDemo1() {
		return "Products are already delivered.";
		
	}

}
