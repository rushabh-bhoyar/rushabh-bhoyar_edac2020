package day4;

import java.sql.Connection;
import java.sql.DriverManager;

public class HelloDatabase {
	
	public static void main(String[] args) {
		
		try {
			
			String driver = "com.mysql.cj.jdbc.Driver";
			String url = "jdbc:mysql://localhost:3306/edac";
			String user = "mysql";
			String password = "mysql";
			
			
			Class.forName(driver);
			
			Connection con = DriverManager.getConnection(url,user, password);
			
			
			System.out.println("CONNECTION.SUCCESS");
			
			con.close();
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}

   }
}