package in.edac;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class HelloJdbcInsertDynamic {

	
	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String url = "jdbc:mysql://localhost:3306/edac";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "edac20";

	public static void main(String[] args) throws Exception {

		Connection con = null;

		try {
			
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter Username");
			String username = sc.nextLine();
			
			System.out.println("Enter password");
			String password = sc.nextLine();
			
			System.out.println("Enter Email");
			String email = sc.nextLine();
			
			System.out.println("Enter Mobile");
			String mobile = sc.nextLine();
			
			sc.close();
			
			// Dynamic Loading!! the class Driver
			Class.forName(DB_DRIVER);

			// Open Connection
			con = DriverManager.getConnection(url, DB_USER, DB_PASSWORD);

			String sql = "INSERT INTO USER (Username, Pswd, Email, Mobile) VALUES (? , ? , ? , ?)";
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			ps.setString(3, email);
			ps.setString(4, mobile);
			ps.executeUpdate();

			System.out.println("Insert Successfully....!");

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			System.out.println("Finally block executed..");
			con.close();
		}

	}

}
