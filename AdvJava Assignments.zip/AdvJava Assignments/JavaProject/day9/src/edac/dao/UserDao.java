package edac.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import java.sql.ResultSet;
import java.util.List;


public class UserDao {

	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/edac";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "edac20";

	public void checkConnection() {

		try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);) {

			System.out.println("Success Try With Resource!!");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean createUser(User user) throws Exception {

		try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);) {

			Class.forName(DB_DRIVER);

			String sql = "INSERT INTO USER (Username,Pswd,Email,Mobile) VALUES (?, ?, ?, ?)";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getEmail());
			ps.setString(4, user.getMobile());

			ps.executeUpdate();
			System.out.println("Insert multiple entries dynamically..!!");

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
			//return false;
		}

	}
	
	public boolean updateUser(User user) throws Exception {
		
		try(Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);) {
			
			Class.forName(DB_DRIVER);
			
			String sql = "UPDATE USER SET Username=?, Pswd=?, Email=?, Mobile=? WHERE ID=?";
			
			PreparedStatement ps =  con.prepareStatement(sql);
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getEmail());
			ps.setString(4, user.getMobile());
			ps.setInt(5, user.getId());
			
			ps.executeUpdate();
			
			return true;
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
			//return false;
		}
	}
	
	
	public boolean deleteUser(User user) throws Exception {
		
		try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);){
			
			Class.forName(DB_DRIVER);
			
			String sql ="DELETE FROM USER WHERE ID=?";
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, user.getId());
			
			ps.executeUpdate();
			
			System.out.println("Record deleted");
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
			//return false;
		}
	}
	
	public List<User> readAllUser() throws Exception {
		
		try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);){
			Class.forName(DB_DRIVER);
			
			String sql = "SELECT *FROM USER";
			PreparedStatement ps = con.prepareStatement(sql);
			
			ResultSet rs = ps.executeQuery();
			
			List<User> list = new ArrayList<User>();
			while(rs.next()) {
				
				int colId = rs.getInt("ID");
				String colUsername = rs.getString("Username");
				String colEmail = rs.getString("Email");
				String colMobile = rs.getString("Mobile");
				
				User user = new User();
				user.setId(colId);
				user.setUsername(colUsername);
				user.setEmail(colEmail);
				user.setMobile(colMobile);
				
				list.add(user);
				
			}
			
			System.out.println("Read all data from database");
			return list;
			
		} catch (Exception e) {
			
			e.printStackTrace();
			throw e;
		}
		
		
	}

	public static void main(String[] args) throws Exception {

		UserDao dao = new UserDao();

		dao.checkConnection();
         
		//Create user
		//User user = new User("Rushikesh J", "rushi$16", "rushijoshi@gmail.com", "9856432456");
		//dao.createUser(user);
		//User user = new User("Mayuresh", "mayur05", "mayuresh@gmail.com", "9023564822");
		//dao.createUser(user);
		
		
		//Update user
		//User user = new User("Rohit","rohit20","RKotkar@gmail.com","9076542310");
		//user.setId(4);
		//dao.updateUser(user);
		
		//User user = new User("Rupali","rupali04","RKale@gmail.com","7054368900");
		//user.setId(2);
		//dao.updateUser(user);
		
		//Delete user
		//User user = new User();
		//user.setId(8);
		//dao.deleteUser(user);
		
		List <User> list = dao.readAllUser();
		System.out.println(list);
	}

}
