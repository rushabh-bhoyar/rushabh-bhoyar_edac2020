package edac;

import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HelloServlet4
 */
@WebServlet("/Servlet-4")
public class HelloServlet4 extends HttpServlet {
	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		
		try {
			
			PrintWriter out = response.getWriter();
			
			out.println("Servlet 4");
			
		} catch (Exception e) {
			
			e.printStackTrace();
			
		}
	}		

}
