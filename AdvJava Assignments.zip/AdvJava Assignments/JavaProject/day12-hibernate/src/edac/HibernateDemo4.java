package edac;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateDemo4 {

	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

	public static void main(String[] args) {

		create();
		//update();
		//delete();
		//updateSpecificColumn();
	}

	public static void create() {

		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();

		Person p = new Person();
		p.setFirstName("Ruchit");
		p.setMiddleName("Sudhir");
		p.setLastName("Ramugade");

		session.save(p);

		tx.commit();
		session.close();

	}

	public static void update() {

		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();

		Person p = new Person();
		p.setId(2);
		p.setFirstName("Rushikesh");
		p.setMiddleName("Pradeep");
		p.setLastName("Ghantewar");

		session.update(p);

		tx.commit();
		session.close();

	}

	public static void delete() {

		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();

		Person p = new Person();
		p.setId(7);

		session.delete(p);

		tx.commit();
		session.close();

	}
	
public static void updateSpecificColumn() {
		
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
		Person p = session.find(Person.class, 3);
		p.setFirstName("Ruchit");
		p.setMiddleName("Sudhir");
		p.setLastName("Ramugade");
	
		session.update(p);
		
		tx.commit();
		session.close();
		
	}
}
